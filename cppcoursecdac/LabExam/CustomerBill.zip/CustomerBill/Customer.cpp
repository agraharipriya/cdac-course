#include "Customer.h"

Customer::Customer(string n, int u) : name(n), units(u) {}

Customer::~Customer() {}
