#include "SavingAcc.h"
#include "CurrentAcc.h"
#include "AccountService.h"
#include <iostream>
#include <cstring>
using namespace std;

Account* AccountService::acc[100];
int AccountService::count = 0;

void AccountService::addAccount(int n) {
	const char* fname;
	const char* lname;
	cout<<"Enter Name: "<<fname<<" "<<lname;
	cin>>fname;
	cin>>lname;
	const char* mobile;
	cout<<"Enter Mobile Number: "<<mobile;
	cin>>mobile;
	const char* email;
	cout<<"Enter Email: "<<email;
	cin>>email;
	
	if (n == 1) {
		
		int transactionsPerDay;
		cout << "Enter Transactions Per Day ";
		cin >> transactionsPerDay;
		
		acc[count++] = new CurrentAccount(transactionsPerDay);
	}
	
	else if (n == 2) {
		const char* chequeBookNumber;
		cout << "Enter Cheque Book Number: ";
		cin >> chequeBookNumber;
		
		acc[count++] = new SavingAccount(chequeBookNumber);
	}
}


void AccountService::displayAll() {
	cout << "All Accounts are:" << endl;
	for (int i=0; i<count; i++) {
		acc[i]->display();
	}
}

 int AccountService::searchByAccNum(const char* accId){
	Account* result[100];
 	int cnt = -1;
	for (int i=0; i<count; i++) {
		if (strcmp(acc[i]->getId(), accId) == 0) {
			result[++cnt] = acc[i];
		}
	}
	return cnt;
 }
 int AccountService::searchByName(const char* name){
	Account* result[100];
 	int cnt = -1;
	for (int i=0; i<count; i++) {
		if (strcmp(acc[i]->generateId(), name) == 0) {
			result[++cnt] = acc[i];
		}
	}
	return cnt;
 }
void AccountService::displayCurrAcc() {
	cout << "Current Account are:" << endl;
	for (int i=0; i<count; i++) {
		if (dynamic_cast<CurrentAccount*>(acc[i]))
			acc[i]->display();
	}
}

void AccountService::displaySavAcc() {
	cout << "Saving Accounts are:" << endl;
	for (int i=0; i<count; i++) {
		if (dynamic_cast<SavingAccount*>(acc[i]))
			acc[i]->display();
			cout << endl;
	}
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
