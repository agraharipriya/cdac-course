#include <iostream>
using namespace std;

// Function to accept array
void acceptarray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        cout << " Element " << i + 1 << " : ";
        cin >> arr[i];
    }
}

// Function to display array
void displayArr(int arr[], int size)
{
    cout << " Array elements : ";
    for (int i = 0; i < size; ++i)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int findmaxArr(int arr[], int size)
{
    int max = arr[0];
    for (int i = 0; i < size; i++)
    {
        if (arr[i] > max)
        {
            max = arr[i];
        }
    }
    return max;
}

int findminArr(int arr[], int size)
{
    int min = arr[0];
    for (int i = 0; i < size; i++)
    {
        if (arr[i] < min)
        {
            min = arr[i];
        }
    }
    return min;
}

int findsum(int arr[], int size)
{
    int sum = 0;
    for (int i = 0; i < size; i++)
    {
        sum = sum + arr[i];
    }
    return sum;
}

int searchnum(int arr[], int size)
{
    int num;
    cout << "Enter a number to search : " << endl;
    cin >> num;
    bool found = false;
    for (int i = 0; i < size; i++)
    {
        if (num == arr[i])
        {
            cout << num << " found in at index" << i << endl;
            found = true;
            break;
        }
    }
    if (!found)
    {
        cout << num << " not found in array." << endl;
    }
    return 0;
}

void numdivisible(int arr[], int size)
{
    int num;
    cout << "Enter a number to check divisibilty :  " << endl;
    cin >> num;
    for (int i = 0; i < size; i++)
    {
        if (arr[i] % num == 0)
        {
            cout << arr[i] << " is divisible by " << num << endl;
        }
        else
        {
            cout << arr[i] << " is not divisible by " << num << endl;
        }
    }
}

void numaverage(int arr[], int size) {
    int count = 0, sum = 0;
    for (int i = 0; i < size; i++) {
        if (arr[i] % 6 == 0) {
            count++;
            sum += arr[i];
        }
    }

    if (count == 0) {
        cout << "No numbers divisible by 6." << endl;
    } else {
        float average = (float)sum / count;
        cout << "Average of numbers divisible by 6 = " << average << endl;
    }
}

int main()
{
    int myarr[50];
    int size,choice;
    cout << "Enter size of array : " << endl;
    cin >> size;

    acceptarray(myarr, size);
    displayArr(myarr, size);

    
    cout<<"1. Find Maximum"<<endl;
    cout<<"2. Find Minimum"<<endl;
    cout<<"3. Addition of all numbers"<<endl;
    cout<<"4. Search a number"<<endl;
    cout<<"5. Find numbers divisible by given number"<<endl;
    cout<<"6. Average of all numbers divisible by 6"<<endl;
    cin>>choice;

    switch(choice){
        case 1: cout << "Maximum = " << findmaxArr(myarr, size) << endl; break;
        case 2: cout << "Minimum = " << findminArr(myarr, size) << endl; break;
        case 3: cout << "Sum = " << findsum(myarr, size) << endl; break;
        case 4: searchnum(myarr, size); break;
        case 5: numdivisible(myarr, size); break;
        case 6: numaverage(myarr, size);break;
        default: cout<<"Enter a valid choice !"<<endl;
    }
    
    return 0;
}
