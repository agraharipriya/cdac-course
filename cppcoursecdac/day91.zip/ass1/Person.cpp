#include "Person.h"
#include "Address.h"
#include <iostream>
#include<cstring>
using namespace std;

Person::Person(){
	id=0;
	name=nullptr;
	}
Person::Person(const char* str,const char* cy, const char* stt,int p,int id, const char* n): addr(str,cy,stt,p){
	this->id=id;
	name = new char[strlen(n)+1];
	strcpy(name,n);
	}
Person::~Person(){
	if(name)
	delete[] name;
}


Person::setId(int id){
	this->id=id;
}
Person::setName(const char* n){
	delete[] name;
		name=new char[strlen(n)+1];
		strncpy(name,n);
}

Person::getId(){
	return id;
}

Person::getName(){
	return name;
}
