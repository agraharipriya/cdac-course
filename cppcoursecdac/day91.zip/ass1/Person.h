#include "Address.h"

class Person{
	int id;
	char* name;
	Address* addr;
	
public :
	//default constructor
	Person();

	//parameterised constructor
	Person(int id, const char* n, Address* addr);

	//destructor
	~Person();

	//setter method
	void setId(int id);
	void setName(const char* n);
 


	//getter method
	int getId();
	const char* getName();
	

	//display method
	void display();








};
other.

