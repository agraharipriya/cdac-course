class Address{
   char * street;
   char* city;
   char* state;
   int pin;
public:
	//default constructor
	Address();

	//parameterised constructor
	Address(const char* str, const char* cy,  const char* stt, int p);
	
	//destructor
	~Address();
	
	//setter method
	void setStreet(const char* str);
	void setCity(const char* cy);
	void setState(const char* stt);
	void setPin(int p);

	//getter method
	const char* getStreet();
	const char* getCity();
	const char* getState();
	int getPin();

	//display method
	void display();
};
