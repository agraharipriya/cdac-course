#include "Address.h"
#include <iostream>
#include <cstring>
using namespace std;

//default constructor
Address::Address(
	cout<<"In default constructor "<<endl;
	street=nullptr;
	city=nullptr;
	state=nullptr;
	pin=0;
)

//Parameterised constructor
Address::Address(const char* str, const char* cy, const char* stt, int p){
	cout<<"In Parameterised Constructor "<<endl;
	street= new char[strlen(str)+1];
	strncpy(street,str);
	city= new char[strlen(cy)+1];
	strncpy(city,cy);
	state= new char[strlen(stt)+1];
	strncpy(state,stt);
	pin=p;
}

//destructor
Address::~Address(){
	cout<<"In Destructor"<<endl;
	if (street)
	delete[] street;
	if (city)
	delete[] city;
	if (state)
	delete[] state;
}


//setter method
inline void Address::setStreet(const char* str){
		delete[] street;
		street=new char[strlen(str)+1];
		strncpy(street,str);
}

inline void Address::setCity(const char* cy){
		delete[] city;
		city=new char[strlen(cy)+1];
		strncpy(city,cy);
}

inline void Address::setState(const char* stt){
		delete[] state;
		state=new char[strlen(stt)+1];
		strncpy(state,stt);
}

inline void Address::setPin(int p){
		pin=p;
}

//getter method

inline char* Address::getStreet(){
		return street;
}
	
inline char* Address::getCity(){
		return city;
}

inline char* Address::getState(){
		return state;
}

inline int Address::getPin(){
 		return pin;
}

//display method
void Address::display(){
	cout<<"Street Name : "<<(street?street:"Not available")<<endl;
	cout<<"City Name : "<<(city?city:"Not available")<<endl;
	cout<<"State Name : "<<(state?state:"Not available")<<endl;
	cout<<"Pin : "<<pin<<endl;
}





















